const NoPage = () => {
	return <h1>404 not found</h1>;
  };
  
  export default NoPage;